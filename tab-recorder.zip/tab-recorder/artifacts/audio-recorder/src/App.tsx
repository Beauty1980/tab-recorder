import { useState, useRef, useEffect, useCallback } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Mic, Square, Download, AlertCircle, RefreshCw, KeyRound, Loader2, FileText, BookOpen, ListChecks, Tag, ChevronRight, Layers } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const queryClient = new QueryClient();

type RecordingState = "idle" | "recording" | "done";

interface StudySection {
  heading: string;
  content: string;
  examples?: string[];
  steps?: string[];
}

interface StudyNotes {
  title: string;
  overview: string;
  sections: StudySection[];
  terms: { term: string; definition: string }[];
  key_takeaways: string[];
}

function formatDuration(seconds: number) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) {
    return `${h}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  }
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function Home() {
  const [recordingState, setRecordingState] = useState<RecordingState>("idle");
  const [duration, setDuration] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [apiKey, setApiKey] = useState<string>(() => sessionStorage.getItem("openai_api_key") ?? "");
  const [showKey, setShowKey] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [transcription, setTranscription] = useState<string | null>(null);
  const [transcriptionError, setTranscriptionError] = useState<string | null>(null);
  const [generatingNotes, setGeneratingNotes] = useState(false);
  const [studyNotes, setStudyNotes] = useState<StudyNotes | null>(null);
  const [studyNotesError, setStudyNotesError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<number | null>(null);

  const stopTimer = useCallback(() => {
    if (intervalRef.current) {
      window.clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  const stopStreamTracks = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  }, []);

  useEffect(() => {
    return () => {
      stopTimer();
      stopStreamTracks();
    };
  }, [stopTimer, stopStreamTracks]);

  const handleApiKeyChange = (value: string) => {
    setApiKey(value);
    sessionStorage.setItem("openai_api_key", value);
  };

  const generateStudyNotes = useCallback(async (text: string) => {
    const key = sessionStorage.getItem("openai_api_key") ?? "";
    if (!key.trim() || !text.trim()) return;

    setGeneratingNotes(true);
    setStudyNotesError(null);
    setStudyNotes(null);

    try {
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${key.trim()}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "gpt-4o",
          response_format: { type: "json_object" },
          messages: [
            {
              role: "system",
              content: `Ты — эксперт по созданию исчерпывающих учебных конспектов. Твоя цель — создать конспект настолько подробный, чтобы студент мог полностью восстановить содержание лекции, не слушая её повторно.

На основе транскрипции лекции создай детальный конспект на русском языке и верни его строго в виде JSON-объекта со следующей структурой:
{
  "title": "точное название темы лекции",
  "overview": "общий обзор лекции в 3-5 предложениях — о чём она, какие главные идеи охватывает",
  "sections": [
    {
      "heading": "название раздела/темы",
      "content": "подробное и развёрнутое объяснение всего, что было сказано по этой теме — не пропускай ни одной детали, объясняй каждый тезис полностью",
      "examples": ["полное описание примера 1, если упоминался", "полное описание примера 2"],
      "steps": ["шаг 1 с полным объяснением", "шаг 2 с полным объяснением"]
    }
  ],
  "terms": [
    {"term": "термин", "definition": "полное и точное определение термина с контекстом из лекции"}
  ],
  "key_takeaways": ["вывод 1 — полное предложение", "вывод 2 — полное предложение"]
}

Правила:
- Создай отдельный раздел в "sections" для каждой темы или концепции, упомянутой в лекции — не объединяй разные темы.
- Поле "content" каждого раздела должно быть максимально подробным — минимум 3-5 предложений.
- Включи "examples" только если примеры реально упоминались; включи "steps" только если описывался процесс или алгоритм.
- В "terms" включи ВСЕ специальные термины, определения, формулы и понятия из лекции.
- "key_takeaways" — главные выводы и то, что студент должен запомнить после лекции.
- Все значения строго на русском языке. Не пропускай ничего из транскрипции.`,
            },
            {
              role: "user",
              content: `Транскрипция:\n\n${text}`,
            },
          ],
        }),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        const msg = body?.error?.message ?? `API error ${res.status}`;
        throw new Error(msg);
      }

      const data = await res.json();
      const raw = data.choices?.[0]?.message?.content ?? "{}";
      const parsed: StudyNotes = JSON.parse(raw);
      setStudyNotes(parsed);
    } catch (err: any) {
      setStudyNotesError(err.message ?? "Не удалось создать конспект. Проверьте ключ API и попробуйте снова.");
    } finally {
      setGeneratingNotes(false);
    }
  }, []);

  const transcribeBlob = useCallback(async (blob: Blob) => {
    const key = sessionStorage.getItem("openai_api_key") ?? "";
    if (!key.trim()) {
      setTranscriptionError("Введите ключ OpenAI API выше для транскрипции.");
      return;
    }

    setTranscribing(true);
    setTranscriptionError(null);
    setTranscription(null);

    try {
      const formData = new FormData();
      formData.append("file", blob, "recording.webm");
      formData.append("model", "whisper-1");

      const res = await fetch("https://api.openai.com/v1/audio/transcriptions", {
        method: "POST",
        headers: { Authorization: `Bearer ${key.trim()}` },
        body: formData,
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body?.error?.message ?? `API error ${res.status}`);
      }

      const data = await res.json();
      const text: string = data.text ?? "";
      setTranscription(text);

      if (text.trim()) {
        await generateStudyNotes(text);
      }
    } catch (err: any) {
      setTranscriptionError(err.message ?? "Transcription failed. Check your API key and try again.");
    } finally {
      setTranscribing(false);
    }
  }, [generateStudyNotes]);

  const handleStart = async () => {
    setError(null);
    setAudioUrl(null);
    setDuration(0);
    setTranscription(null);
    setTranscriptionError(null);
    setStudyNotes(null);
    setStudyNotesError(null);
    chunksRef.current = [];

    try {
      if (!navigator.mediaDevices?.getDisplayMedia) {
        throw new Error("Your browser does not support tab audio capture.");
      }

      let stream: MediaStream;
      try {
        stream = await navigator.mediaDevices.getDisplayMedia({ video: false, audio: true });
      } catch {
        stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
      }

      if (stream.getAudioTracks().length === 0) {
        stream.getTracks().forEach((t) => t.stop());
        throw new Error("No audio track was selected. Make sure to share a tab and check 'Share audio'.");
      }

      const audioStream = new MediaStream(stream.getAudioTracks());
      streamRef.current = stream;

      const mediaRecorder = new MediaRecorder(audioStream, { mimeType: "audio/webm" });
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) chunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
        setRecordingState("done");
        stopTimer();
        stopStreamTracks();
        transcribeBlob(blob);
      };

      const onTrackEnded = () => {
        if (mediaRecorderRef.current?.state === "recording") handleStop();
      };
      stream.getTracks().forEach((t) => { t.onended = onTrackEnded; });

      mediaRecorder.start();
      setRecordingState("recording");

      intervalRef.current = window.setInterval(() => {
        setDuration((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      if (err.name === "NotAllowedError" || err.message?.includes("Permission denied")) {
        setError("Permission to capture tab audio was denied. Please try again and ensure you select 'Share audio'.");
      } else {
        setError(err.message || "An error occurred while trying to capture audio.");
      }
    }
  };

  const handleStop = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
      mediaRecorderRef.current.stop();
    }
  };

  const reset = () => {
    setRecordingState("idle");
    setDuration(0);
    setAudioUrl(null);
    setError(null);
    setTranscription(null);
    setTranscriptionError(null);
    setStudyNotes(null);
    setStudyNotesError(null);
    chunksRef.current = [];
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-start bg-background p-4 sm:p-8 pt-8 sm:pt-12">

      {/* API Key Field */}
      <div className="w-full max-w-md mb-6">
        <Label htmlFor="api-key-input" className="text-sm font-medium text-muted-foreground flex items-center gap-1.5 mb-2">
          <KeyRound className="w-3.5 h-3.5" />
          OpenAI API Key
        </Label>
        <div className="relative">
          <Input
            id="api-key-input"
            data-testid="api-key-input"
            type={showKey ? "text" : "password"}
            value={apiKey}
            onChange={(e) => handleApiKeyChange(e.target.value)}
            placeholder="Enter your OpenAI API key"
            className="pr-20 font-mono text-sm"
          />
          <button
            type="button"
            onClick={() => setShowKey((v) => !v)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground hover:text-foreground transition-colors select-none"
          >
            {showKey ? "Hide" : "Show"}
          </button>
        </div>
        <p className="text-xs text-muted-foreground mt-1.5">
          Your key is used only in this session and never stored on the server.
        </p>
      </div>

      {/* Recorder Card */}
      <Card className="w-full max-w-md shadow-xl border-muted">
        <CardHeader className="text-center pb-8">
          <CardTitle className="text-2xl font-semibold tracking-tight text-foreground">
            Audio Capture
          </CardTitle>
          <CardDescription className="text-muted-foreground mt-2">
            Record audio directly from your browser tab.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center space-y-8">

          {/* Status Indicator */}
          <div className="flex flex-col items-center justify-center space-y-3 h-24">
            {recordingState === "idle" && (
              <div className="flex flex-col items-center text-muted-foreground">
                <Mic className="w-8 h-8 mb-2 opacity-50" />
                <p className="text-sm font-medium">Ready to record</p>
              </div>
            )}
            {recordingState === "recording" && (
              <div className="flex flex-col items-center">
                <div className="relative flex items-center justify-center mb-2">
                  <div className="absolute w-12 h-12 bg-destructive/20 rounded-full animate-ping" />
                  <div className="absolute w-8 h-8 bg-destructive/40 rounded-full animate-pulse" />
                  <div className="relative w-4 h-4 bg-destructive rounded-full" />
                </div>
                <p className="text-sm font-medium text-destructive animate-pulse">Recording</p>
                <p className="text-3xl font-mono tracking-wider font-semibold text-foreground mt-2" data-testid="duration-display">
                  {formatDuration(duration)}
                </p>
              </div>
            )}
            {recordingState === "done" && (
              <div className="flex flex-col items-center text-primary">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mb-2">
                  <Mic className="w-4 h-4" />
                </div>
                <p className="text-sm font-medium text-foreground">Recording saved</p>
                <p className="text-lg font-mono text-muted-foreground mt-1">
                  {formatDuration(duration)}
                </p>
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="w-full flex flex-col items-center gap-4">
            {recordingState === "idle" && (
              <Button
                onClick={handleStart}
                size="lg"
                className="w-full max-w-xs rounded-full h-14 text-base shadow-sm hover:shadow transition-all"
                data-testid="start-button"
              >
                <Mic className="mr-2 w-5 h-5" />
                Start Recording
              </Button>
            )}
            {recordingState === "recording" && (
              <Button
                onClick={handleStop}
                variant="destructive"
                size="lg"
                className="w-full max-w-xs rounded-full h-14 text-base shadow-sm hover:shadow transition-all animate-in fade-in zoom-in duration-200"
                data-testid="stop-button"
              >
                <Square className="mr-2 w-5 h-5 fill-current" />
                Stop Recording
              </Button>
            )}
            {recordingState === "done" && audioUrl && (
              <div className="w-full flex flex-col items-center space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-300">
                <audio controls src={audioUrl} className="w-full h-12" data-testid="audio-player" />
                <div className="flex w-full gap-3">
                  <Button variant="outline" onClick={reset} className="flex-1 h-12">
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Record Again
                  </Button>
                  <Button asChild className="flex-1 h-12">
                    <a href={audioUrl} download="recording.webm" data-testid="download-button">
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </a>
                  </Button>
                </div>
              </div>
            )}
          </div>

          {error && (
            <Alert variant="destructive" className="animate-in fade-in slide-in-from-bottom-2">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription className="text-sm">{error}</AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Transcription Section */}
      {(transcribing || transcription !== null || transcriptionError) && (
        <div className="w-full max-w-md mt-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="flex items-center gap-2 mb-3">
            <FileText className="w-4 h-4 text-primary" />
            <h2 className="text-sm font-semibold text-foreground">Транскрипция</h2>
          </div>
          {transcribing && (
            <div className="flex items-center gap-3 p-4 rounded-xl border bg-card text-muted-foreground text-sm">
              <Loader2 className="w-4 h-4 animate-spin shrink-0" />
              Отправка в Whisper...
            </div>
          )}
          {transcriptionError && !transcribing && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Ошибка транскрипции</AlertTitle>
              <AlertDescription className="text-sm">{transcriptionError}</AlertDescription>
            </Alert>
          )}
          {transcription !== null && !transcribing && (
            <div
              data-testid="transcription-text"
              className="p-4 rounded-xl border bg-card text-foreground text-sm leading-relaxed whitespace-pre-wrap"
            >
              {transcription.trim() === "" ? (
                <span className="text-muted-foreground italic">Речь не обнаружена.</span>
              ) : (
                transcription
              )}
            </div>
          )}
        </div>
      )}

      {/* Study Notes Section */}
      {(generatingNotes || studyNotes !== null || studyNotesError) && (
        <div className="w-full max-w-md mt-6 mb-12 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="flex items-center gap-2 mb-3">
            <BookOpen className="w-4 h-4 text-primary" />
            <h2 className="text-sm font-semibold text-foreground">Учебный конспект</h2>
          </div>

          {generatingNotes && (
            <div className="flex items-center gap-3 p-4 rounded-xl border bg-card text-muted-foreground text-sm">
              <Loader2 className="w-4 h-4 animate-spin shrink-0" />
              GPT-4o создаёт конспект...
            </div>
          )}

          {studyNotesError && !generatingNotes && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Ошибка создания конспекта</AlertTitle>
              <AlertDescription className="text-sm">{studyNotesError}</AlertDescription>
            </Alert>
          )}

          {studyNotes && !generatingNotes && (
            <div data-testid="study-notes" className="rounded-xl border bg-card overflow-hidden">

              {/* Title */}
              <div className="px-5 py-4 border-b bg-primary/5">
                <h3 className="text-base font-semibold text-foreground">{studyNotes.title}</h3>
              </div>

              {/* Overview */}
              {studyNotes.overview && (
                <div className="px-5 py-4 border-b bg-muted/30">
                  <p className="text-sm text-foreground leading-relaxed">{studyNotes.overview}</p>
                </div>
              )}

              {/* Detailed Sections */}
              {studyNotes.sections?.length > 0 && (
                <div className="divide-y">
                  {studyNotes.sections.map((section, i) => (
                    <div key={i} className="px-5 py-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Layers className="w-3.5 h-3.5 text-primary shrink-0" />
                        <h4 className="text-sm font-semibold text-foreground">{section.heading}</h4>
                      </div>
                      <p className="text-sm text-foreground leading-relaxed mb-3">{section.content}</p>

                      {section.steps && section.steps.length > 0 && (
                        <div className="mb-3">
                          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Шаги / процесс</p>
                          <ol className="space-y-1.5">
                            {section.steps.map((step, j) => (
                              <li key={j} className="flex items-start gap-2 text-sm text-foreground">
                                <span className="mt-0.5 flex-shrink-0 w-5 h-5 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center">
                                  {j + 1}
                                </span>
                                {step}
                              </li>
                            ))}
                          </ol>
                        </div>
                      )}

                      {section.examples && section.examples.length > 0 && (
                        <div className="rounded-lg bg-accent/40 px-3 py-2.5">
                          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Примеры</p>
                          <ul className="space-y-1.5">
                            {section.examples.map((ex, j) => (
                              <li key={j} className="flex items-start gap-2 text-sm text-foreground">
                                <ChevronRight className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" />
                                {ex}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Terms */}
              {studyNotes.terms?.length > 0 && (
                <div className="px-5 py-4 border-t">
                  <div className="flex items-center gap-2 mb-3">
                    <Tag className="w-4 h-4 text-primary shrink-0" />
                    <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Важные термины и определения</h4>
                  </div>
                  <dl className="space-y-3">
                    {studyNotes.terms.map((item, i) => (
                      <div key={i} className="rounded-lg border px-3 py-2.5">
                        <dt className="text-sm font-semibold text-foreground">{item.term}</dt>
                        <dd className="text-sm text-muted-foreground mt-1 leading-relaxed">{item.definition}</dd>
                      </div>
                    ))}
                  </dl>
                </div>
              )}

              {/* Key Takeaways */}
              {studyNotes.key_takeaways?.length > 0 && (
                <div className="px-5 py-4 border-t bg-primary/5">
                  <div className="flex items-center gap-2 mb-3">
                    <ListChecks className="w-4 h-4 text-primary shrink-0" />
                    <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Главные выводы</h4>
                  </div>
                  <ul className="space-y-2">
                    {studyNotes.key_takeaways.map((point, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                        <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                        {point}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Home />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
